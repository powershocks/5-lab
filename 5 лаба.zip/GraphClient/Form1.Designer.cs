﻿
namespace GraphClient {
	partial class Form1 {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
			this.Chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.Tb_PointValue = new System.Windows.Forms.TextBox();
			this.Btn_AddPoint = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.Chart1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// Chart1
			// 
			this.Chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			chartArea1.Name = "ChartArea1";
			this.Chart1.ChartAreas.Add(chartArea1);
			legend1.Name = "Legend1";
			this.Chart1.Legends.Add(legend1);
			this.Chart1.Location = new System.Drawing.Point(12, 12);
			this.Chart1.Name = "Chart1";
			series1.ChartArea = "ChartArea1";
			series1.Legend = "Legend1";
			series1.Name = "Series1";
			this.Chart1.Series.Add(series1);
			this.Chart1.Size = new System.Drawing.Size(776, 376);
			this.Chart1.TabIndex = 0;
			this.Chart1.Text = "chart1";
			// 
			// Tb_PointValue
			// 
			this.Tb_PointValue.Location = new System.Drawing.Point(6, 39);
			this.Tb_PointValue.Name = "Tb_PointValue";
			this.Tb_PointValue.Size = new System.Drawing.Size(87, 20);
			this.Tb_PointValue.TabIndex = 2;
			// 
			// Btn_AddPoint
			// 
			this.Btn_AddPoint.Location = new System.Drawing.Point(99, 36);
			this.Btn_AddPoint.Name = "Btn_AddPoint";
			this.Btn_AddPoint.Size = new System.Drawing.Size(93, 25);
			this.Btn_AddPoint.TabIndex = 4;
			this.Btn_AddPoint.Text = "Add point";
			this.Btn_AddPoint.UseVisualStyleBackColor = true;
			this.Btn_AddPoint.Click += new System.EventHandler(this.Btn_AddPoint_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.Tb_PointValue);
			this.groupBox1.Controls.Add(this.Btn_AddPoint);
			this.groupBox1.Location = new System.Drawing.Point(12, 394);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(229, 74);
			this.groupBox1.TabIndex = 5;
			this.groupBox1.TabStop = false;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 13);
			this.label1.TabIndex = 6;
			this.label1.Text = "y = a ^ 2";
			// 
			// Form1
			// 
			this.AcceptButton = this.Btn_AddPoint;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 480);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.Chart1);
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.Chart1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.DataVisualization.Charting.Chart Chart1;
		private System.Windows.Forms.TextBox Tb_PointValue;
		private System.Windows.Forms.Button Btn_AddPoint;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
	}
}

