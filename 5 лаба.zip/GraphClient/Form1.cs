﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace GraphClient {

	public partial class Form1 : Form {
		private Series _timeline = new Series("timeline");
		//private const string _dllPath = @"../../../Debug/GraphLib.dll";
		private const string _dllPath = @"GraphLib.dll";

		[DllImport(_dllPath, CallingConvention = CallingConvention.Cdecl)]
		static extern long GetTimeNow();

		public Form1() {
			InitializeComponent();
		
			_timeline.ChartType = SeriesChartType.Line;

			_timeline.XValueType = ChartValueType.String;
			_timeline.YValueType = ChartValueType.Int32;
			_timeline.Color = Color.Red;

			Chart1.ChartAreas[0].AxisX.IsMarginVisible = false;
			Chart1.ChartAreas[0].AxisX.Title = "Time";
			Chart1.ChartAreas[0].AxisY.Title = "y = a ^ 2";
			//Chart1.ChartAreas[0].AxisY.Maximum = 100;
			Chart1.Series.Add(_timeline);

			/*_timeline.Points.AddXY("16:00", 10);
			_timeline.Points.AddXY("17:00", 50);
			_timeline.Points.AddXY("18:00", 30);*/
			AddPoint1(0);
		}

		private void AddPointImpl(double y) {
			var timestamp = GetTimeNow();
			var dtOffset = DateTimeOffset.FromUnixTimeMilliseconds(timestamp);
			var x = dtOffset.ToLocalTime().ToString("T");
			y = y * y;
			this._timeline.Points.AddXY(x, y);
		}

		private void AddPoint() {
			var y = Tb_PointValue.Text;
			AddPointImpl(Double.Parse(y));
		}

		private void AddPoint1(double y) {
			AddPointImpl(y);
		}

		private void Btn_AddPoint_Click(object sender, EventArgs e) {
			AddPoint();
			Tb_PointValue.Clear();
		}
	}
}
