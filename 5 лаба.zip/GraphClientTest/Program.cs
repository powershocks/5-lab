﻿using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;

namespace GraphClientTest {
	class Program {
        const string dllPath = @"../../../../Debug/GraphLib.dll";

        [DllImport(dllPath, CallingConvention = CallingConvention.Cdecl)]
        static extern int Test(int n);

        [DllImport(dllPath, CallingConvention = CallingConvention.Cdecl)]
        static extern long GetTimeNow();

        static void Main(string[] args) {
            Console.WriteLine(Test(2));
            var timestamp = GetTimeNow();
            Console.WriteLine(timestamp);
            var time = DateTimeOffset.FromUnixTimeMilliseconds(timestamp);
            Console.WriteLine(time.ToLocalTime().ToString("T"));
        }
    }
}
