#include "pch.h"
#include "GraphLib.h"
#include <chrono>

int Test(int n) {
	return n * n;
}

long long GetTimeNow() {
	using namespace std::chrono;
	return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}