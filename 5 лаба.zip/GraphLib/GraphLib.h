#pragma once

#define DLL_EXPORT extern "C" __declspec(dllexport)

DLL_EXPORT int Test(int n);

DLL_EXPORT long long GetTimeNow();
